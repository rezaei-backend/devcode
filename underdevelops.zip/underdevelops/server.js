const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// اجازه CORS (احتیاطاً)
app.use(cors());
app.use(express.json());

// سرو کردن همه‌ی فایل‌های استاتیک از همین پوشه‌ی پروژه
// یعنی هرچی HTML/CSS/JS و ... تو این فولدر هست از طریق http://localhost:3000 در دسترسه
app.use(express.static(path.join(__dirname)));

// یک تابع ساده برای تولید سوال‌ها (فعلاً بدون هوش مصنوعی)
// بعداً می‌تونیم اینجا رو به OpenAI وصل کنیم
function generateQuestions({ language, difficulty, count }) {
  const baseQuestions = [
    {
      text: 'کدام تگ برای بخش اصلی محتوای صفحه مناسب‌تر است؟',
      options: ['<section>', '<main>', '<article>', '<div>'],
      answerIndex: 1
    },
    {
      text: 'برای گرفتن ایمیل کاربر کدام ورودی مناسب است؟',
      options: [
        '<input type="text">',
        '<input type="email">',
        '<input type="url">',
        '<input type="mail">'
      ],
      answerIndex: 1
    },
    {
      text: 'برای اجباری کردن پر کردن یک فیلد فرم از کدام ویژگی استفاده می‌شود؟',
      options: ['validate', 'required', 'must', 'obligatory'],
      answerIndex: 1
    },
    {
      text: 'کدام متاتگ روی توضیح نتایج جستجو بیشتر تاثیر دارد؟',
      options: [
        '<meta name="keywords">',
        '<meta name="viewport">',
        '<meta name="description">',
        '<meta name="robots">'
      ],
      answerIndex: 2
    },
    {
      text: 'برای بارگذاری تنبل تصاویر از چه ویژگی استفاده می‌شود؟',
      options: [
        'loading="lazy"',
        'defer="true"',
        '<lazy>',
        'فقط با CSS'
      ],
      answerIndex: 0
    }
  ];

  // برای اینکه هر سری سوال‌ها فرق کنند، آرایه رو شافل می‌کنیم
  const shuffled = [...baseQuestions].sort(() => Math.random() - 0.5);

  const questions = [];
  for (let i = 0; i < count; i++) {
    const base = shuffled[i % shuffled.length];
    questions.push({
      text: `[${language.toUpperCase()} - ${difficulty}] ${base.text}`,
      options: base.options,
      // توجه: این فیلد باید اسمش answerIndex باشد چون فرانت همین رو می‌خواند
      answerIndex: base.answerIndex
    });
  }

  return questions;
}

// API که فرانت توی fetch صدا می‌زند
app.post('/api/generate-questions', (req, res) => {
  const { language = 'html', difficulty = 'medium', count = 10 } = req.body || {};

  const num = Number(count) || 10;

  const questions = generateQuestions({ language, difficulty, count: num });

  res.json({ questions });
});

// راه‌اندازی سرور
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
