@extends('panel.layouts.master')

@section('content')

    <div class="contentbar">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-sm">

                    <div class="card-header d-flex justify-content-between">
                        <h5 class="mb-0">تنظیمات سایت</h5>
                        <a href="{{ route('Settings.edit', 1) }}" class="btn btn-success-rgba">ویرایش</a>
                    </div>

                    <div class="card-body">

                        @if(!$setting)
                            <div class="text-center py-5">
                                <p class="text-muted">تنظیمات وجود ندارد.</p>
                                <a href="{{ route('Settings.edit', 1) }}" class="btn btn-primary">ایجاد</a>
                            </div>
                        @else

                            <p><strong>نام سایت:</strong> {{ $setting->site_name }}</p>
                            <p><strong>زبان:</strong> {{ strtoupper($setting->default_language) }}</p>
                            <p><strong>ایمیل تماس:</strong> {{ $setting->contact_email ?? '—' }}</p>

                            <hr>

                            <div class="row">
                                <div class="col-md-6 text-center">
                                    <strong>لوگو:</strong><br>
                                    @if($setting->logo_path)
                                        <img src="{{ asset('images/settings/' . $setting->logo_path) }}"
                                             style="max-height:90px">
                                    @else
                                        <div class="bg-light p-3 border rounded">بدون لوگو</div>
                                    @endif
                                </div>

                                <div class="col-md-6 text-center">
                                    <strong>فاوآیکون:</strong><br>
                                    @if($setting->favicon_path)
                                        <img src="{{ asset('images/settings/' . $setting->favicon_path) }}"
                                             style="width:32px;height:32px">
                                    @else
                                        <div class="bg-light p-3 border rounded">—</div>
                                    @endif
                                </div>
                            </div>

                        @endif

                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection
