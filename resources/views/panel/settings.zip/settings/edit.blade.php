@extends('panel.layouts.master')

@section('content')
    <div class="contentbar">
        <div class="row">
            <div class="col-lg-12">
                <div class="card m-b-30 shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">ویرایش تنظیمات سایت</h5>
                    </div>
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form action="{{ route('Settings.update', $setting->id) }}" method="POST" enctype="multipart/form-data" id="settings-form">
                            @csrf
                            @method('PUT')

                            <!-- اطلاعات اصلی -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="site_name" class="font-weight-bold">نام سایت <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" id="site_name" name="site_name"
                                           value="{{ old('site_name', $setting->site_name) }}" required>
                                    <x-input-error :messages="$errors->get('site_name')" class="mt-1 text-danger" />
                                </div>
                                <div class="col-md-6">
                                    <label for="default_language" class="font-weight-bold">زبان پیش‌فرض <span class="text-danger">*</span></label>
                                    <select class="form-control form-control-sm" id="default_language" name="default_language" required>
                                        <option value="fa" {{ old('default_language', $setting->default_language) == 'fa' ? 'selected' : '' }}>فارسی</option>
                                        <option value="en" {{ old('default_language', $setting->default_language) == 'en' ? 'selected' : '' }}>English</option>
                                        <option value="ar" {{ old('default_language', $setting->default_language) == 'ar' ? 'selected' : '' }}>العربية</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="contact_email" class="font-weight-bold">ایمیل تماس</label>
                                    <input type="email" class="form-control form-control-sm" id="contact_email" name="contact_email"
                                           value="{{ old('contact_email', $setting->contact_email) }}">
                                    <x-input-error :messages="$errors->get('contact_email')" class="mt-1 text-danger" />
                                </div>
                                <div class="col-md-6">
                                    <label for="meta_description" class="font-weight-bold">توضیحات متا (سئو)</label>
                                    <textarea class="form-control form-control-sm" id="meta_description" name="meta_description" rows="3">{{ old('meta_description', $setting->meta_description) }}</textarea>
                                    <x-input-error :messages="$errors->get('meta_description')" class="mt-1 text-danger" />
                                </div>
                            </div>

                            <!-- آپلود لوگو -->
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="font-weight-bold d-block mb-2">لوگو</label>
                                    <small class="text-muted d-block mb-2">حداکثر 2MB | JPG, PNG, SVG, WebP</small>

                                    @if ($setting->logo_path)
                                        <div class="current-image-box p-3 border rounded bg-light mb-3" id="current-logo-box">
                                            <div class="text-center position-relative d-inline-block">
                                                <img src="{{ asset('images/settings/' . $setting->logo_path) }}" alt="لوگو"
                                                     class="img-thumbnail" style="max-height: 90px; border-radius: 0.5rem;">
                                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 mt-2 me-2"
                                                        onclick="removeImage('logo')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                            <input type="hidden" name="remove_logo" id="remove_logo" value="0">
                                        </div>
                                    @endif

                                    <div class="image-upload-container" id="logo-upload">
                                        <input type="file" id="logo_input" name="logo" accept="image/*" hidden>
                                        <div class="drop-zone" id="drop-zone-logo">
                                            <p class="drop-text">فایل را اینجا بکشید یا <span class="text-primary" style="cursor:pointer;text-decoration:underline;">انتخاب کنید</span></p>
                                            <div id="logo-preview" class="image-preview mt-2"></div>
                                        </div>
                                    </div>
                                    <x-input-error :messages="$errors->get('logo')" class="mt-1 text-danger" />
                                </div>

                                <!-- آپلود فاوآیکون -->
                                <div class="col-md-6">
                                    <label class="font-weight-bold d-block mb-2">فاوآیکون</label>
                                    <small class="text-muted d-block mb-2">حداکثر 1MB | ICO, PNG, SVG</small>

                                    @if ($setting->favicon_path)
                                        <div class="current-image-box p-3 border rounded bg-light mb-3" id="current-favicon-box">
                                            <div class="text-center position-relative d-inline-block">
                                                <img src="{{ asset('images/settings/' . $setting->favicon_path) }}" alt="فاوآیکون"
                                                     class="img-thumbnail" style="width: 48px; height: 48px; border-radius: 0.5rem;">
                                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 mt-1 me-1"
                                                        onclick="removeImage('favicon')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                            <input type="hidden" name="remove_favicon" id="remove_favicon" value="0">
                                        </div>
                                    @endif

                                    <div class="image-upload-container" id="favicon-upload">
                                        <input type="file" id="favicon_input" name="favicon" accept=".ico,.png,.svg" hidden>
                                        <div class="drop-zone" id="drop-zone-favicon">
                                            <p class="drop-text">فایل را اینجا بکشید یا <span class="text-primary" style="cursor:pointer;text-decoration:underline;">انتخاب کنید</span></p>
                                            <div id="favicon-preview" class="image-preview mt-2"></div>
                                        </div>
                                    </div>
                                    <x-input-error :messages="$errors->get('favicon')" class="mt-1 text-danger" />
                                </div>
                            </div>

                            <div class="text-center mt-5">
                                <button type="submit" class="btn btn-primary-rgba px-5 py-2">ذخیره تغییرات</button>
                                <a href="{{ route('Settings.index') }}" class="btn btn-outline-secondary px-5 py-2 ms-2">لغو</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- استایل -->
    <style>
        .current-image-box { background: #f8f9fa; border: 1px solid #dee2e6; }
        .drop-zone { border: 2px dashed #ccc; border-radius: 0.5rem; padding: 1.5rem; text-align: center; background: #fafafa; transition: 0.3s; cursor: pointer; }
        .drop-zone.dragover { border-color: #1976d2; background: #e3f2fd; }
        .drop-text { margin: 0; color: #666; font-size: 0.9rem; }
        .image-preview { max-height: 120px; overflow: hidden; border-radius: 0.375rem; margin-top: 0.5rem; text-align: center; }
        .image-preview img { max-height: 100px; border-radius: 0.375rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    </style>

    <!-- جاوااسکریپت -->
    <script>
        function removeImage(type) {
            document.getElementById(`current-${type}-box`).remove();
            document.getElementById(`remove_${type}`).value = '1';
        }

        document.addEventListener('DOMContentLoaded', function () {
            const setups = [
                { input: 'logo_input', drop: 'drop-zone-logo', preview: 'logo-preview' },
                { input: 'favicon_input', drop: 'drop-zone-favicon', preview: 'favicon-preview' }
            ];

            setups.forEach(s => {
                const dropZone = document.getElementById(s.drop);
                const input = document.getElementById(s.input);
                const preview = document.getElementById(s.preview);

                dropZone.addEventListener('click', () => input.click());
                input.addEventListener('change', () => handleFile(input.files[0], preview));

                ['dragover', 'dragenter'].forEach(e => dropZone.addEventListener(e, preventDefault));
                ['dragleave', 'dragend'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.remove('dragover')));
                dropZone.addEventListener('drop', e => {
                    e.preventDefault();
                    dropZone.classList.remove('dragover');
                    const file = e.dataTransfer.files[0];
                    if (file && (file.type.startsWith('image/') || file.name.endsWith('.ico'))) {
                        input.files = e.dataTransfer.files;
                        handleFile(file, preview);
                    }
                });
            });

            function preventDefault(e) {
                e.preventDefault();
                e.currentTarget.classList.add('dragover');
            }

            function handleFile(file, previewEl) {
                if (!file) return;
                const reader = new FileReader();
                reader.onload = e => previewEl.innerHTML = `<img src="${e.target.result}" alt="پیش‌نمایش">`;
                reader.readAsDataURL(file);
            }
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
@endsection
